import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from training.flash_vtg_gmr.contracts import (
    canonical_json_sha256,
    key_string,
    normalize_source,
    query_key,
    read_jsonl,
    resolve_media_path,
    row_key,
    sha256_file,
    validate_encoder_mask,
    video_key,
    video_stem,
    write_json_artifact,
)


def _load_feature(path, expected_dim):
    with np.load(path, allow_pickle=False) as archive:
        if set(archive.files) != {"features"}:
            raise ValueError(f"{path}: expected only key 'features', got {archive.files}")
        features = archive["features"]
    if features.ndim != 2 or features.shape[1] != expected_dim:
        raise ValueError(f"{path}: expected (T,{expected_dim}), got {features.shape}")
    if features.dtype != np.float32:
        raise ValueError(f"{path}: expected float32, got {features.dtype}")
    if not np.isfinite(features).all():
        raise ValueError(f"{path}: contains NaN or Inf")
    norms = np.linalg.norm(features, axis=1)
    if np.any(norms <= 1e-12):
        raise ValueError(f"{path}: contains a zero-norm real row")
    return features, norms


def _load_text(path, store_length, model_length):
    with np.load(path, allow_pickle=False) as archive:
        required = {"last_hidden_state", "attention_mask"}
        if not required.issubset(archive.files):
            raise ValueError(f"{path}: missing keys {sorted(required - set(archive.files))}")
        hidden = archive["last_hidden_state"]
        mask = archive["attention_mask"]
    if hidden.shape != (store_length, 512):
        raise ValueError(f"{path}: expected ({store_length},512), got {hidden.shape}")
    if hidden.dtype != np.float32:
        raise ValueError(f"{path}: expected float32 hidden states, got {hidden.dtype}")
    if not np.isfinite(hidden).all():
        raise ValueError(f"{path}: contains NaN or Inf")
    bool_mask, valid_length = validate_encoder_mask(mask, store_length, model_length)
    valid_norms = np.linalg.norm(hidden[bool_mask], axis=1)
    if np.any(valid_norms <= 1e-12):
        raise ValueError(f"{path}: contains a zero-norm valid token row")
    return hidden, bool_mask, valid_length, valid_norms


def _media_duration(path):
    try:
        import cv2
    except ImportError as exc:
        raise RuntimeError("OpenCV is required to audit media duration") from exc
    capture = cv2.VideoCapture(str(path))
    try:
        if not capture.isOpened():
            raise ValueError(f"Could not open media file: {path}")
        fps = float(capture.get(cv2.CAP_PROP_FPS))
        frame_count = float(capture.get(cv2.CAP_PROP_FRAME_COUNT))
        if fps <= 0 or frame_count <= 0:
            raise ValueError(f"Invalid FPS/frame count for {path}: {fps}/{frame_count}")
        return frame_count / fps
    finally:
        capture.release()


def _relative_or_absolute(path):
    path = Path(path)
    try:
        return str(path.resolve().relative_to(Path.cwd().resolve()))
    except ValueError:
        return str(path.resolve())


def audit(args):
    split_paths = [Path(path) for path in args.split_jsonl]
    split_names = [path.stem.lower() for path in split_paths]
    if len(set(split_names)) != len(split_names):
        raise ValueError(f"Split paths have duplicate stems: {split_names}")

    rows_by_split = {}
    all_rows = []
    for split, path in zip(split_names, split_paths):
        rows = read_jsonl(path)
        rows_by_split[split] = rows
        all_rows.extend((split, row) for row in rows)

    query_owners = {}
    canonical_qid_splits = defaultdict(set)
    video_splits = defaultdict(set)
    row_keys = set()
    vid_query_splits = defaultdict(set)
    video_rows = {}
    source_counts = Counter()
    for split, row in all_rows:
        source = normalize_source(row.get("dataset_source"))
        source_counts[source] += 1
        qkey = key_string(query_key(args.dataset_setting, split, source, row["qid"]))
        rkey = key_string(row_key(args.dataset_setting, split, source, row["qid"], row["vid"]))
        vkey = key_string(video_key(args.dataset_setting, source, row["vid"]))
        if qkey in query_owners:
            raise ValueError(f"Duplicate query key: {qkey}")
        if rkey in row_keys:
            raise ValueError(f"Duplicate row key: {rkey}")
        query_owners[qkey] = (split, row)
        canonical_qid_splits[(args.dataset_setting, source, str(row["qid"]))].add(split)
        row_keys.add(rkey)
        video_splits[vkey].add(split)
        normalized_query = " ".join(str(row["query"]).lower().split())
        vid_query_splits[(vkey, normalized_query)].add(split)
        video_rows.setdefault(vkey, (source, row["vid"], row))

    video_leaks = {key: sorted(value) for key, value in video_splits.items() if len(value) > 1}
    qid_leaks = {
        key_string(key): sorted(value)
        for key, value in canonical_qid_splits.items()
        if len(value) > 1
    }
    query_leaks = {
        f"{key[0]}|{key[1]}": sorted(value)
        for key, value in vid_query_splits.items()
        if len(value) > 1
    }
    if qid_leaks or video_leaks or query_leaks:
        raise ValueError(
            f"Cross-split identity leakage: qids={len(qid_leaks)}, "
            f"videos={len(video_leaks)}, vid-query={len(query_leaks)}"
        )

    slowfast_dir = Path(args.slowfast_dir)
    clip_dir = Path(args.clip_dir)
    text_dir = Path(args.text_dir)
    video_inventory = {}
    numerical = {
        "artifact_type": "f-old-numerical-audit",
        "video_count": 0,
        "query_count": 0,
        "nonfinite_count": 0,
        "zero_norm_real_row_count": 0,
        "cross_stream_t_mismatch_count": 0,
        "text_mask_noncontiguous_count": 0,
        "padding_hidden_nonzero_row_count": 0,
        "text_valid_length_min": None,
        "text_valid_length_max": None,
    }

    for vkey, (source, vid, representative) in sorted(video_rows.items()):
        stem = video_stem(vid)
        slowfast_path = slowfast_dir / f"{stem}.npz"
        clip_path = clip_dir / f"{stem}.npz"
        if not slowfast_path.is_file() or not clip_path.is_file():
            raise FileNotFoundError(f"Missing video feature for {vkey}")
        slowfast, slowfast_norms = _load_feature(slowfast_path, 2304)
        clip, clip_norms = _load_feature(clip_path, 512)
        if len(slowfast) != len(clip):
            raise ValueError(
                f"Cross-stream T mismatch for {vkey}: {len(slowfast)} != {len(clip)}"
            )
        if not (0 < len(slowfast) <= args.max_v_l):
            raise ValueError(f"Unexpected T={len(slowfast)} for {vkey}")
        media_path = resolve_media_path(args.video_root, source, vid)
        duration_media = _media_duration(media_path)
        duration_label = float(representative["duration"])
        duration_grid = len(slowfast) * args.clip_length
        video_inventory[vkey] = {
            "video_key": json.loads(json.dumps(video_key(args.dataset_setting, source, vid))),
            "source": source,
            "vid": vid,
            "vid_stem": stem,
            "slowfast_path": _relative_or_absolute(slowfast_path),
            "clip_path": _relative_or_absolute(clip_path),
            "media_path": _relative_or_absolute(media_path),
            "slowfast_sha256": sha256_file(slowfast_path),
            "clip_sha256": sha256_file(clip_path),
            "media_size_bytes": media_path.stat().st_size,
            "T_slowfast_raw": len(slowfast),
            "T_clip_raw": len(clip),
            "T_final": len(clip),
            "D_label": duration_label,
            "D_media": duration_media,
            "D_grid": duration_grid,
            "D_decode": min(duration_media, duration_grid),
            "duration_delta_label": duration_label - duration_grid,
            "duration_delta_media": duration_media - duration_grid,
            "slowfast_raw_norm_min": float(slowfast_norms.min()),
            "slowfast_raw_norm_max": float(slowfast_norms.max()),
            "clip_raw_norm_min": float(clip_norms.min()),
            "clip_raw_norm_max": float(clip_norms.max()),
        }
        numerical["video_count"] += 1

    query_inventory = {}
    valid_lengths = []
    for qkey, (split, row) in sorted(query_owners.items()):
        qid = row["qid"]
        path = text_dir / f"qid{qid}.npz"
        if not path.is_file():
            raise FileNotFoundError(f"Missing text feature for {qkey}: {path}")
        hidden, mask, valid_length, valid_norms = _load_text(
            path, args.text_store_length, args.text_model_length
        )
        padding_nonzero = int(np.count_nonzero(np.linalg.norm(hidden[~mask], axis=1) > 1e-12))
        query_inventory[qkey] = {
            "query_key": query_key(
                args.dataset_setting,
                split,
                row.get("dataset_source"),
                qid,
            ),
            "qid": qid,
            "source": normalize_source(row.get("dataset_source")),
            "split": split,
            "text_path": _relative_or_absolute(path),
            "text_sha256": sha256_file(path),
            "valid_length": valid_length,
            "valid_norm_min": float(valid_norms.min()),
            "valid_norm_max": float(valid_norms.max()),
            "padding_hidden_nonzero_rows": padding_nonzero,
        }
        numerical["query_count"] += 1
        numerical["padding_hidden_nonzero_row_count"] += padding_nonzero
        valid_lengths.append(valid_length)

    numerical["text_valid_length_min"] = min(valid_lengths)
    numerical["text_valid_length_max"] = max(valid_lengths)
    numerical["passed"] = True

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    numerical_path = output.parent / "numerical_audit.json"
    identity_path = output.parent / "identity_audit.json"
    text_alignment_path = output.parent / "text_alignment_audit.json"

    write_json_artifact(numerical_path, numerical)
    write_json_artifact(
        identity_path,
        {
            "artifact_type": "f-old-identity-audit",
            "dataset_setting": args.dataset_setting,
            "split_row_counts": {key: len(value) for key, value in rows_by_split.items()},
            "source_row_counts": dict(source_counts),
            "query_key_count": len(query_owners),
            "video_key_count": len(video_rows),
            "row_key_count": len(row_keys),
            "cross_split_video_collisions": video_leaks,
            "cross_split_qid_collisions": qid_leaks,
            "cross_split_vid_query_collisions": query_leaks,
            "passed": True,
        },
    )
    write_json_artifact(
        text_alignment_path,
        {
            "artifact_type": "f-old-text-alignment-audit",
            "status": "unverified",
            "reason": (
                "F-old masks and hidden-state numerics are verified; locked OpenAI CLIP "
                "text re-encoding has not been run. Token-index HMSA remains blocked."
            ),
            "npz_mask_verified": True,
            "blocks_adapter_aec": False,
            "blocks_token_index_hmsa": True,
        },
    )

    manifest = {
        "artifact_type": "f-old-feature-manifest",
        "setting": "f-old",
        "dataset_setting": args.dataset_setting,
        "known_provenance": False,
        "slowfast_dir": _relative_or_absolute(slowfast_dir),
        "clip_dir": _relative_or_absolute(clip_dir),
        "text_dir": _relative_or_absolute(text_dir),
        "video_root": _relative_or_absolute(args.video_root),
        "split_jsonl": {
            split: {"path": _relative_or_absolute(path), "sha256": sha256_file(path)}
            for split, path in zip(split_names, split_paths)
        },
        "concat_order": ["slowfast", "clip"],
        "per_stream_normalization": True,
        "normalization_eps": args.normalization_eps,
        "clip_length": args.clip_length,
        "text_context_length_store": args.text_store_length,
        "text_context_length_model": args.text_model_length,
        "text_mask_direction": "1_valid_0_pad",
        "temporal_grid": "half-open, D_grid=T*clip_length",
        "cross_stream_length_policy": "exact-or-fail",
        "text_token_alignment_status": "unverified",
        "video_inventory": video_inventory,
        "query_inventory": query_inventory,
        "inventory_sha256": canonical_json_sha256(
            {"videos": video_inventory, "queries": query_inventory}
        ),
        "numerical_audit": {
            "path": _relative_or_absolute(numerical_path),
            "sha256": sha256_file(numerical_path),
        },
        "identity_audit": {
            "path": _relative_or_absolute(identity_path),
            "sha256": sha256_file(identity_path),
        },
        "text_alignment_audit": {
            "path": _relative_or_absolute(text_alignment_path),
            "sha256": sha256_file(text_alignment_path),
        },
    }
    return write_json_artifact(output, manifest)


def build_parser():
    parser = argparse.ArgumentParser(description="Audit and freeze existing F-old features")
    parser.add_argument("--mode", default="existing", choices=("existing",))
    parser.add_argument("--dataset_setting", default="standard")
    parser.add_argument("--slowfast_dir", required=True)
    parser.add_argument("--clip_dir", required=True)
    parser.add_argument("--text_dir", required=True)
    parser.add_argument("--video_root", required=True)
    parser.add_argument("--split_jsonl", nargs="+", required=True)
    parser.add_argument("--concat_order", default="slowfast,clip")
    parser.add_argument("--clip_length", type=float, default=2.0)
    parser.add_argument("--max_v_l", type=int, default=75)
    parser.add_argument("--text_store_length", type=int, default=77)
    parser.add_argument("--text_model_length", type=int, default=40)
    parser.add_argument("--normalization_eps", type=float, default=1e-5)
    parser.add_argument("--require_equal_video_lengths", action="store_true")
    parser.add_argument("--fail_on_nonfinite", action="store_true")
    parser.add_argument("--output", required=True)
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    if args.concat_order.split(",") != ["slowfast", "clip"]:
        parser.error("--concat_order must be slowfast,clip")
    audit(args)


if __name__ == "__main__":
    main()
