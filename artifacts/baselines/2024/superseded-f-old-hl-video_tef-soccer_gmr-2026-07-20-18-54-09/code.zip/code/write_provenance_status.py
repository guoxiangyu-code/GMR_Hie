import argparse
from pathlib import Path

from training.flash_vtg_gmr.contracts import write_json_artifact


ALLOWED_STATUSES = (
    "NOT_RUN_WITH_REASON",
    "EXACT",
    "COMPATIBLE",
    "INCOMPATIBLE",
)


def main():
    parser = argparse.ArgumentParser(description="Write the non-blocking F-new status artifact")
    parser.add_argument("--status", required=True, choices=ALLOWED_STATUSES)
    parser.add_argument("--reason", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if not args.reason.strip():
        parser.error("--reason must not be empty")
    write_json_artifact(
        Path(args.output),
        {
            "artifact_type": "f-new-provenance-status",
            "status": args.status,
            "reason": args.reason.strip(),
            "blocks_f_old_mainline": False,
        },
    )


if __name__ == "__main__":
    main()
